#!/usr/bin/env python3
"""Quick HTTP host test"""
import asyncio
from simple_mcp_host import SimpleMCPHost

async def test_http_host():
    print("🧪 Testing HTTP Host directly...")
    
    try:
        # Create host instance
        host = SimpleMCPHost()
        
        # Check if agents are registered
        agent_status = host.registry.get_agent_status()
        print(f"✅ HTTP Host: {agent_status['total_agents']} agents, {agent_status['total_tools']} tools")
        
        # Test tool listing (simulates what the /tools endpoint does)
        tools = host.registry.get_all_tools()
        mcp_tools = []
        for tool_name, tool_schema in tools.items():
            mcp_tools.append({
                "name": tool_name,
                "description": tool_schema.get("description", ""),
                "inputSchema": tool_schema.get("inputSchema", {})
            })
        
        print(f"✅ HTTP Host: Tool conversion works ({len(mcp_tools)} tools)")
        
        # Test a simple tool call (file agent ping)
        if "file_info" in tools:
            try:
                result = await host.registry.call_tool("file_info", {"file_path": "README.md"})
                print("✅ HTTP Host: Tool calling works")
            except Exception as e:
                print(f"⚠️ HTTP Host: Tool call test failed: {e}")
        
        print("✅ HTTP Host: Core functionality is working")
        return True
        
    except Exception as e:
        print(f"❌ HTTP Host error: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    asyncio.run(test_http_host())
