#!/usr/bin/env python3
"""
Quick validation that MCP server components work
"""
try:
    # Test imports
    print("Testing imports...")
    from pure_mcp_server import PureAgenticMCPServer
    from registry import AgenticToolRegistry
    from protocol import MCPRequest, MCPResponse
    print("✅ All imports successful")
    
    # Test server creation
    print("Testing server creation...")
    server = PureAgenticMCPServer()
    print("✅ Server created successfully")
    
    # Test registry
    print("Testing registry...")
    status = server.registry.get_agent_status()
    print(f"✅ Registry working: {status['total_agents']} agents, {status['total_tools']} tools")
    
    # Test protocol models
    print("Testing protocol models...")
    request = MCPRequest(method="test", id=1)
    response = MCPResponse(id=1, result={"status": "ok"})
    
    # Test model_dump (this was the main issue)
    request_dict = request.model_dump()
    response_dict = response.model_dump()
    print(f"✅ Protocol models working: jsonrpc={request_dict.get('jsonrpc')}")
    
    print("\n🎉 All core components are working correctly!")
    print("\nServer is ready for Claude Desktop connection.")
    print("Make sure to restart Claude Desktop to pick up the config changes.")
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()
