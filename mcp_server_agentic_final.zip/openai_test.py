#!/usr/bin/env python3
"""Quick OpenAI agent test"""
import asyncio
import logging
from config import Config
from agents.openai_agent import OpenAIAgent

async def test_openai():
    print("🧪 Testing OpenAI Agent...")
    
    config = Config()
    print(f"OpenAI API key configured: {'Yes' if config.openai_api_key else 'No'}")
    
    if not config.openai_api_key:
        print("❌ No OpenAI API key found")
        return
    
    # Test agent creation
    try:
        agent = OpenAIAgent(config)
        print(f"✅ Agent created, available: {agent.is_available()}")
        
        if not agent.is_available():
            print("❌ Agent not available")
            return
        
        # Test simple chat
        print("🧪 Testing simple chat...")
        result = await agent.handle_tool_call("openai_chat", {
            "message": "Hello, just testing!"
        })
        print(f"✅ Chat result: {result.get('content', 'No content')[:100]}...")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    asyncio.run(test_openai())
