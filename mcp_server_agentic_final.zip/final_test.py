#!/usr/bin/env python3
"""Final validation - this should work with Claude Desktop now"""
import asyncio
from pure_mcp_server import PureAgenticMCPServer

async def main():
    print("🎯 FINAL VALIDATION")
    print("=" * 50)
    
    server = PureAgenticMCPServer()
    
    # Test the exact request that Claude sends
    claude_init_request = {
        "method": "initialize",
        "params": {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "claude-ai", "version": "0.1.0"}
        },
        "jsonrpc": "2.0",
        "id": 0
    }
    
    response = await server.handle_request(claude_init_request)
    
    print("✅ Server Response Format:")
    print(f"   Keys: {list(response.keys())}")
    print(f"   Has 'result': {'result' in response}")
    print(f"   Has 'error': {'error' in response}")
    print(f"   JSONRPC version: {response.get('jsonrpc')}")
    
    # Check agent status
    status = server.registry.get_agent_status()
    print(f"\n✅ Server Status:")
    print(f"   Agents: {status['total_agents']}")
    print(f"   Tools: {status['total_tools']}")
    print(f"   Available: {list(status['agents'].keys())}")
    
    print(f"\n🚀 Server is ready for Claude Desktop!")
    print("   1. Restart Claude Desktop")
    print("   2. The server should connect successfully")
    print("   3. You'll have access to Ollama and File agent tools")

if __name__ == "__main__":
    asyncio.run(main())
