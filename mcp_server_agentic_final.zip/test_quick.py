#!/usr/bin/env python3
"""
Quick test of MCP server functionality
"""
import asyncio
import json
from pure_mcp_server import PureAgenticMCPServer

async def test_requests():
    server = PureAgenticMCPServer()
    
    print("🧪 Testing MCP server requests...")
    
    # Test 1: Initialize
    print("\n1️⃣ Testing initialize...")
    init_request = {
        'method': 'initialize', 
        'params': {'protocolVersion': '2024-11-05', 'capabilities': {}}, 
        'jsonrpc': '2.0', 
        'id': 0
    }
    
    try:
        response = await server.handle_request(init_request)
        print("✅ Initialize: OK")
        print(f"   Protocol version: {response['result']['protocolVersion']}")
        print(f"   Server: {response['result']['serverInfo']['name']}")
    except Exception as e:
        print(f"❌ Initialize failed: {e}")
        return False
    
    # Test 2: List tools
    print("\n2️⃣ Testing tools/list...")
    list_request = {
        'method': 'tools/list', 
        'params': {},
        'jsonrpc': '2.0', 
        'id': 1
    }
    
    try:
        response = await server.handle_request(list_request)
        tools = response.get('result', {}).get('tools', [])
        print(f"✅ Tools/list: OK ({len(tools)} tools)")
        for tool in tools[:5]:  # Show first 5 tools
            name = tool.get('name', 'unknown')
            desc = tool.get('description', 'no description')[:60]
            print(f"   - {name}: {desc}")
    except Exception as e:
        print(f"❌ Tools/list failed: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # Test 3: Call a simple tool (file_read)
    print("\n3️⃣ Testing tools/call...")
    
    # First, check if file_read tool exists
    file_tools = [t for t in tools if 'file' in t.get('name', '').lower()]
    if file_tools:
        tool_name = file_tools[0]['name']
        print(f"   Testing tool: {tool_name}")
        
        call_request = {
            'method': 'tools/call',
            'params': {
                'name': tool_name,
                'arguments': {'file_path': 'README.md'}  # Try to read README
            },
            'jsonrpc': '2.0',
            'id': 2
        }
        
        try:
            response = await server.handle_request(call_request)
            if 'error' in response:
                print(f"⚠️ Tool call returned error: {response['error']}")
            else:
                print("✅ Tool call: OK")
                content = response.get('result', {}).get('content', [])
                if content and len(content) > 0:
                    text = content[0].get('text', '')[:100]
                    print(f"   Result preview: {text}...")
        except Exception as e:
            print(f"❌ Tool call failed: {e}")
    else:
        print("⚠️ No file tools found to test")
    
    print("\n🎉 All tests completed!")
    return True

# Quick test to check response format
async def test_response_format():
    server = PureAgenticMCPServer()
    
    # Test what our initialize response looks like
    init_request = {
        'method': 'initialize', 
        'params': {'protocolVersion': '2024-11-05', 'capabilities': {}}, 
        'jsonrpc': '2.0', 
        'id': 0
    }
    
    response = await server.handle_request(init_request)
    print('\n🔍 Response format check:')
    print(f'Keys: {list(response.keys())}')
    print(f'Has null fields: {any(v is None for v in response.values())}')
    
    # Check for unwanted fields
    if 'error' in response and response['error'] is None:
        print('❌ Contains null error field')
    elif 'error' not in response or response.get('error') is None:
        print('✅ No unwanted error field')
    
    return response

if __name__ == "__main__":
    # Run original test
    asyncio.run(test_requests())
    
    # Run format check
    print('\n' + '='*50)
    asyncio.run(test_response_format())
