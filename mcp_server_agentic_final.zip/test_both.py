#!/usr/bin/env python3
"""
Test both MCP server and HTTP host to ensure both work
"""
import asyncio
import json
import httpx
import subprocess
import time
import sys

async def test_mcp_server():
    """Test MCP server functionality"""
    print("🧪 Testing MCP Server...")
    try:
        from pure_mcp_server import PureAgenticMCPServer
        
        server = PureAgenticMCPServer()
        
        # Test initialize request
        init_request = {
            "method": "initialize",
            "params": {"protocolVersion": "2024-11-05", "capabilities": {}},
            "jsonrpc": "2.0",
            "id": 0
        }
        
        response = await server.handle_request(init_request)
        
        if response.get("result") and "protocolVersion" in response["result"]:
            print("✅ MCP Server: Initialize works")
            
            # Test tools list
            tools_request = {
                "method": "tools/list",
                "params": {},
                "jsonrpc": "2.0",
                "id": 1
            }
            
            tools_response = await server.handle_request(tools_request)
            if tools_response.get("result") and "tools" in tools_response["result"]:
                tool_count = len(tools_response["result"]["tools"])
                print(f"✅ MCP Server: Tools list works ({tool_count} tools)")
                return True
            else:
                print("❌ MCP Server: Tools list failed")
                return False
        else:
            print("❌ MCP Server: Initialize failed")
            return False
            
    except Exception as e:
        print(f"❌ MCP Server error: {e}")
        return False

async def test_http_host():
    """Test HTTP host functionality"""
    print("\n🧪 Testing HTTP Host...")
    try:
        # Start HTTP host in background
        process = subprocess.Popen(
            [sys.executable, "simple_mcp_host.py"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        # Give it time to start
        await asyncio.sleep(3)
        
        async with httpx.AsyncClient(timeout=10.0) as client:
            # Test ping endpoint
            try:
                ping_response = await client.get("http://localhost:8000/ping")
                if ping_response.status_code == 200:
                    print("✅ HTTP Host: Ping works")
                    
                    # Test tools list endpoint
                    tools_response = await client.get("http://localhost:8000/tools")
                    if tools_response.status_code == 200:
                        data = tools_response.json()
                        if data.get("status") == "success":
                            tool_count = data.get("tool_count", 0)
                            print(f"✅ HTTP Host: Tools endpoint works ({tool_count} tools)")
                            
                            # Kill the process
                            process.terminate()
                            process.wait()
                            return True
                        else:
                            print("❌ HTTP Host: Tools endpoint returned error")
                    else:
                        print(f"❌ HTTP Host: Tools endpoint failed ({tools_response.status_code})")
                else:
                    print(f"❌ HTTP Host: Ping failed ({ping_response.status_code})")
            except Exception as e:
                print(f"❌ HTTP Host: Request failed: {e}")
        
        # Kill the process
        process.terminate()
        process.wait()
        return False
        
    except Exception as e:
        print(f"❌ HTTP Host error: {e}")
        return False

async def main():
    print("🎯 TESTING BOTH MCP SERVER AND HTTP HOST")
    print("=" * 60)
    
    # Test MCP server
    mcp_works = await test_mcp_server()
    
    # Test HTTP host
    http_works = await test_http_host()
    
    print("\n" + "=" * 60)
    print("📊 FINAL RESULTS:")
    print(f"   MCP Server (Claude Desktop): {'✅ WORKING' if mcp_works else '❌ BROKEN'}")
    print(f"   HTTP Host (Streamlit UI): {'✅ WORKING' if http_works else '❌ BROKEN'}")
    
    if mcp_works and http_works:
        print("\n🎉 BOTH SYSTEMS ARE WORKING!")
        print("   - Claude Desktop should connect successfully")
        print("   - Streamlit UI should work properly")
    else:
        print("\n⚠️ SOME ISSUES DETECTED - NEED TO FIX")

if __name__ == "__main__":
    asyncio.run(main())
